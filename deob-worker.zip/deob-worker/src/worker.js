import { webcrack } from 'webcrack';

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const obfCode = url.searchParams.get('code');
    if (!obfCode) {
      return new Response('Missing ?code= parameter', { status: 400 });
    }

    try {
      const result = await webcrack(obfCode);
      const escaped = result.code
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

      const html = `<!DOCTYPE html>
<html>
<head><title>Deobfuscator</title></head>
<body>
  <textarea style="width:100%;height:70vh">${escaped}</textarea>
  <button onclick="navigator.clipboard.writeText(document.querySelector('textarea').value)">Copy</button>
</body>
</html>`;
      
      return new Response(html, { headers: { 'Content-Type': 'text/html' } });
    } catch (err) {
      return new Response('Error: ' + err.message, { status: 500 });
    }
  }
}
