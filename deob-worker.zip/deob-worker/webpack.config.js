const path = require('path');

export default {
  mode: 'production',
  target: 'webworker',
  entry: './src/worker.js',
  output: {
    path: path.resolve('./dist'),
    filename: 'worker.js',
    libraryTarget: 'module',
  },
  experiments: {
    outputModule: true,
  },
  resolve: {
    fallback: {
      fs: false,
      path: false,
      crypto: false,
      stream: false,
    }
  }
};
